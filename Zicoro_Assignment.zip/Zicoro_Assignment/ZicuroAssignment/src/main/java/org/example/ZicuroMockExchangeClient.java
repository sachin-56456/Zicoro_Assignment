package org.example;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.Socket;
import java.util.ArrayList;
import java.util.List;
import java.io.FileWriter;

public class ZicuroMockExchangeClient {

    private static final String SERVER_HOST = "localhost";
    private static final int SERVER_PORT = 3000;

    public static void main(String[] args) {

        try {
            Socket socket = new Socket(SERVER_HOST, SERVER_PORT);
            DataInputStream inputStream = new DataInputStream(socket.getInputStream());
            DataOutputStream outputStream = new DataOutputStream(socket.getOutputStream());

            sendStreamAllPacketsRequest(outputStream);
            List<Packet> packets = handleResponse(inputStream);
            handleMissingSequences(outputStream, packets);
            generateJsonFile(packets);
            socket.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }


    private static void sendStreamAllPacketsRequest(DataOutputStream outputStream) throws IOException {
        outputStream.writeByte(1);
        outputStream.flush();
    }

    private static List<Packet> handleResponse(DataInputStream inputStream) throws IOException {
        List<Packet> packets = new ArrayList<>();
        try {
            byte packetCount = inputStream.readByte();
            for (int i = 0; i < packetCount; i++) {
                String symbol = readString(inputStream, 4);
                char indicator = (char) inputStream.readByte();
                int quantity = inputStream.readInt();
                int price = inputStream.readInt();
                int sequence = inputStream.readInt();
                packets.add(new Packet(symbol, indicator, quantity, price, sequence));
            }
        } catch (Exception ignored) {
        }
        return packets;
    }

    private static void handleMissingSequences(DataOutputStream outputStream, List<Packet> packets) throws IOException {
        int lastSequence = packets.get(packets.size() - 1).getSequence();

        for (int i = 1; i < lastSequence; i++) {
            boolean found = false;

            for (Packet packet : packets) {
                if (packet.getSequence() == i) {
                    found = true;
                    break;
                }
            }

            if (!found) {
                sendResendPacketRequest(outputStream, i);
            }
        }
    }

    private static void sendResendPacketRequest(DataOutputStream outputStream, int sequence) throws IOException {
        outputStream.writeByte(2);
        outputStream.writeInt(sequence);
        outputStream.flush();
    }

    private static void generateJsonFile(List<Packet> packets) {
        // Implement logic to generate a JSON file from the received packet data
        // You may use a JSON library like Gson or Jackson for this task
        System.out.println(packets);
        try {
            FileWriter writer = new FileWriter("output.json");
            writer.write("[");
            for (int i = 0; i < packets.size(); i++) {
                writer.write(packets.get(i).toString());
                if (i != packets.size() - 1) {
                    writer.write(",");
                }
            }
            writer.write("]");
            writer.close();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }

    }

    private static String readString(DataInputStream inputStream, int length) throws IOException {
        byte[] buffer = new byte[length];
        inputStream.readFully(buffer);
        return new String(buffer, "UTF-8");
    }
}

class Packet {
    private String symbol;
    private char indicator;
    private int quantity;
    private int price;
    private int sequence;

    public Packet(String symbol, char indicator, int quantity, int price, int sequence) {
        this.symbol = symbol;
        this.indicator = indicator;
        this.quantity = quantity;
        this.price = price;
        this.sequence = sequence;
    }

    public String getSymbol() {
        return symbol;
    }

    public char getIndicator() {
        return indicator;
    }

    public int getQuantity() {
        return quantity;
    }

    public int getPrice() {
        return price;
    }

    public int getSequence() {
        return sequence;
    }

    @Override
    public String toString() {
        return "{" +
                "\"symbol\":\"" + symbol + "\"" +
                ", \"indicator\":\"" + indicator + "\"" +
                ", \"quantity\":\"" + quantity + "\"" +
                ", \"price\":\"" + price + "\"" +
                ", \"sequence\":\"" + sequence + "\"" +
                '}';
    }
}